
import java.util.Scanner;
public class Main {

  //Strings constants
  private static final String GAME = "GAME";
  private static final String HELP = "HELP";
  private static final String MOVE = "MOVE";
  private static final String CREATE ="CREATE";
  private static final String ATTACK = "ATTACK";
  private static final String STATUS = "STATUS";
  private static final String BUNKERS = "BUNKERS";
  private static final String PLAYERS = "PLAYERS";
  private static final String QUIT = "QUIT";

  //Messages constants
  private static final String INVALID_COMMAND = "Invalid command.";
  private static final String QUIT_MSG = "Bye.";
  private static final String LONG_HELP = "game - Create a new game\n move - Move a player\n create - Create a player in a bunker\n attack - Attack with all players of the              current   team\n status - Show the current state of the game\n map - Show the map of the current team\n bunkers - List the bunkers of the current team, by the order they were         seized\n players - List the active players of the current team, by the order they were created \n help - Show available commands\n quit - End program execution \n";
  private static final String SHORT_HELP = "game - Create a new game\n help - Show available commands\n quit - End program execution";
  private static final String BUNKER_NOT_CREATED_MSG = "Bunker not created.";
  private static final String FATAL_ERROR_MSG = "FATAL ERROR: Insufficient number of teams";
  
public static void main(String[] args) {
    Scanner in = new Scanner(System.in);

    GameSys sys = new GameSys();
    String comm;

    do {
        comm = getCommand(in);
        switch (comm) {
            case GAME:
                initGame(sys, in);
                break;
            case HELP:
                helpCom(sys);
                break;
            case QUIT:
                System.out.println(QUIT_MSG);
                break;
            default:
                System.out.println(INVALID_COMMAND);
                break;
        }
    } while (!comm.equals(QUIT) && !sys.gameHaveStarted);

    while (!comm.equals(QUIT) && sys.validGame()) {
        comm = getCommand(in);
        switch (comm) {
            case GAME:
                initGame(sys, in);
                break;
            case HELP:
                helpCom(sys);
                break;
            case MOVE:
                move(sys, in);
                break;
            case CREATE:
                create(sys, in);
                break;
            case ATTACK:
                attack(sys, in);
                break;
            case STATUS:
                listStatus(sys);
                break;
            case MAP:
                listTeamMap(sys);
                break;
            case BUNKERS:
                listBunkers(sys);
                break;
            case PLAYERS:
                listPlayers(sys);
                break;
            case QUIT:
                System.out.println(QUIT_MSG);
                break;
            default:
                System.out.println(INVALID_COMMAND);
                break;
        }
    }
    in.close();
}

    private static String getCommand(Scanner in) {
      String input;
      input = in.nextLine().toUpperCase().trim();
      return input;
  }

    private static void helpCom(GameSys sys){
      if(sys.gameHaveStarted){
        System.out.printf(LONG_HELP);
      }else{
        System.out.printf(SHORT_HELP);
        
      }
    }
  private static void initGame(GameSys sys, Scanner in){
    
    int width = in.nextInt();
    int height = in.nextInt();
    int nTeam = in.nextInt();
    int nBunkers = in.nextInt();
    in.nextLine();
    sys.startGame(width, height, nTeam, nBunkers);
    createBunkers(sys, in, nBunkers);
    createTeams(sys, in, nTeam);
    if(!sys.validGame()){
      System.out.println(FATAL_ERROR_MSG);
    }
  }

  private static void createBunkers(GameSys sys, Scanner in, int nBunkers){
    for (int i = 0; i<nBunkers; i++){
      int x = in.nextInt();
      int y = in.nextInt();
      int treasury = in.nextInt();
      String name = in.nextLine();
      if (!sys.createBunker(x, y, treasury, name))
        System.out.println(BUNKER_NOT_CREATED_MSG);
    }
  }

  private static void createTeams(GameSys sys, Scanner in, int nTeam){
    for (int i = 0; i<nBunkers; i++){
      String name = in.next();
      String bunker = in.nextLine();
      if (!sys.createTeam(name, bunker))
        System.out.println(BUNKER_NOT_CREATED_MSG);
    }
  }

}