public class BunkerClass implements Bunker{
      private static final String RED = "RED";
      private static final String GREEN = "GREEN";
      private static final String BLUE = "BLUE";
  
      private int x;
      private int y;
      private int treasury;
      String name;
      private boolean isOccupied;
      private boolean claimed;
      
  
      public BunkerClass(int x, int y, int initTreasury, String name){
           this.x = x;
           this.y = y;
           treasury = initTreasury;
           this.name = name;
           isOccupied = false;
           claimed = false;
      }

      public int getX(){
           return x;
      }

      public int getY(){
           return y;
      }

      public int getTreasury(){
           return treasury;
      }

      public String getName(){
           return name;
      }

      public boolean getIsOccupied(){
           return isOccupied;
      }

      public boolean isClaimed(){
           return claimed;
      }
  
      public void addCoin(){
           treasury++;
      }

      public void spendCoins(String type){
           if(type.equals(RED)){
                treasury -= 4;
           }else if(type.equals(GREEN) || type.equals(BLUE)){
                treasury -= 2;
      }
      public void setIsClaimed(){
        claimed = !claimed;
      }

    
}