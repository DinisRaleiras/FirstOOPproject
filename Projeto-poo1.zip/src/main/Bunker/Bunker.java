public interface Bunker{
      int getX();
      int getY();
      int getTreasury();
      String getName();
      boolean isOccupied();
      boolean isClaimed();
      void addCoin();
      void spendCoins(String type);
    public void setIsClaimed();
}