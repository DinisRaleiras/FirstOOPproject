public interface Game{
      void createTeam(String name, String bunkerName);
      int searchBunkerIndex(String name);
      boolean createBunker (int x, int y, int treasury, String name);
      boolean validTeamName(String name);
      boolean validGame();
}