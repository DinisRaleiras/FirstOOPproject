public class GameClass implements Game{
      private Team[] teams;
      private int width;
      private int height;
      private int bunkersNumber;
      private int teamsNumber;
      private String[][] map;
      private Bunker[] bunkers;
  
      public GameClass(int width, int height, int teamsNumber, int bunkersNumber){
            teams = new Team[teamsNumber];
            bunkers = new Bunker[bunkersNumber];
            this.width = width;
            this.height = height;
            this.teamsNumber = 0;
            this.bunkersNumber = 0;
            map = new String[heigth+1][width+1];
            int i = 0;
            for(int j = 1; j < map[i].length; j++){
                  map[i][j] = toString(j);
            }
            j = 0;
            for(i = 1; i < map.length; i++){
                  map[i][j] = toString(i);
            }
            map[0][0] = "**";
          
      }
    public boolean createBunker (int x, int y, int treasury, String name){
       if (x < 1 || x > width || y < 1 || y > height || treasury < 0 || searchBunkerIndex(name) == -1) {
         return false;
       }else{
         bunkers[bunkersNumber++] = new BunkerClass(x, y, treasury, name); 
         return true;
       }
    }
    private int searchBunkerIndex(String name){
      int i = 0;
      while(i < bunkersNumber && !name.equals(bunkers[i].getName())){
        i++;
      }
      if(i == bunkersNumber){
        return -1;
      }else{
        return i;
      }
      
    }

    public boolean validGame(){
      return teamsNumber >= 2;
    }
  
    public boolean createTeam (String name, String bunkerName){
      if (!validTeamName(name) || serchBunkerIndex(bunkerName) == -1){
        return false;
      }else{
        Bunker bunker = bunkers[serchBunkerIndex(bunkerName)];
        if(bunker.isClaimed()){
          return false;
        }else{
          teams[teamsNumber] = new TeamClass(name, bunker);
          teams[teamsNumber].addBunker(bunker);
          teamsNumber++;
          bunker.setIsClaimed();
          return true;
        }
        
        
      }
    }
  
    private boolean validTeamName(String name){
      int i = 0;
      while (i < teamsNumber && !name.equals(teams[i].getName())){
        i++;
      }
      return i == teamsNumber;
    }
}