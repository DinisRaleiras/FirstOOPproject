public class Teamclass implements Team{
  private Bunker[] teamBunkers;
  private int nBunkers;
  private Player[] players;
  private int nPlayers;

  public Teamclass(){
    teambunkers = new Bunker[10];
    nBunkers = 0;
    players = new Player[10];
    nPlayers = 0;
  }
  public void addBunker(Bunker bunker){
    teamBunkers[nBunkers++] = bunker;
  }
  
  
}