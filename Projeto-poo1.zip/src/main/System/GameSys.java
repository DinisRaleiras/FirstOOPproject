public interface GameSys{
  
      boolean isValid(String type);
      void startGame(int width, int height, int teamsNumber, int bunkersNumber);
      boolean createBunker(itn x, int y, int tresury, String name);
      boolean validGame();
      boolean createTeam (String name, String bunker);
}