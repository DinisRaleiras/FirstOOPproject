public class GameSysClass implements GameSys {
      private static final String RED = "RED";
      private static final String GREEN = "GREEN";
      private static final String BLUE = "BLUE";
  
      private Game g1;
      private boolean gameHaveStarted;
  
      public GameSysClass(){
            gameHaveStarted = false;
            g1 = null;
      }

    public void startGame(int width, int height, int teamsNumber, int bunkersNumber){
          g1 = new GameClass(width, height, teamsNumber, bunkersNumber);
          gameHaveStarted = true;
    }

    public boolean isValid(String type){
          return type.equals(RED) || type.equals(GREEN) || type.equals(BLUE);
    }
  
    public boolean createBunker(int x, int y, int treasury, String name){
      return g1.createBunker(x, y, treasury, name);
    }
    public boolean createTeam (String name, String bunker){
      return g1.createTeam(name, bunker);
      
    }

    public boolean validGame(){
          return g1.validGame();
    }
}