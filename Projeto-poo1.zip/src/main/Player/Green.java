public class Green extends Player {

}