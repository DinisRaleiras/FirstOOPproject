public abstract class Player implements Player {

} 