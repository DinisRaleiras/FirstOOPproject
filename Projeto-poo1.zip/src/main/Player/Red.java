public class Red extends Player {

}