public interface Player {

  }