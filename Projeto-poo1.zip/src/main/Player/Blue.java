public class Blue extends Player {
  
}